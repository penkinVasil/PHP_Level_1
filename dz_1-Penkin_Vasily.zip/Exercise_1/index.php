<?php 

// Задание_1

echo " <br>";
echo "<b>Задание_1</b><br>";
echo " <br>";

$a = 5;
$b = '05';

echo "$a == $b: "; 
echo var_dump($a == $b) . '<br>';                         // Почему true?
echo " <br>"; 											  // True, т.к. сравнение только по значению: 5 = 5
															  
echo "(int)'012345': ";
echo var_dump((int)'012345') . '<br>';                    // Почему 12345?
echo " <br>"; 											  // Число 12345, т.к. тип данных Str преобразован в Int

echo "(float)123.0 === (int)123.0: ";
echo var_dump((float)123.0 === (int)123.0) . '<br>'; 	  // Почему false?
echo " <br>"; 											  // False, т.к. сравнение по типу данных и по значению; различные типы данных 

echo "(int)0 === (int)'hello, world': ";
echo var_dump((int)0 === (int)'hello, world') . '<br>';   // Почему true?
echo "<br><hr>"; 										  // True, т.к. (int)'hello, world' будет преобразован из Str в Int со значением 0, типы данных и значения станут одинаковыми


