<?php 
$title = "About Me";
$h1 = "Exercise_2_(version_2)";
$curYear = "2022";

include "template.php";


