<?php 
$title = "About Me";
$h1 = "Exercise_2_(version_3)";
$curYear = "2022";

$content = file_get_contents("template.html");

$content = str_replace("{{ title }}", $title, $content);
$content = str_replace("{{ h1 }}", $h1, $content);
$content = str_replace("{{ curYear }}", $curYear, $content);

echo $content;